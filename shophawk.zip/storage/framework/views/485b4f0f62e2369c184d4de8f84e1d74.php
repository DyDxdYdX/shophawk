<div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
    <div class="p-6 bg-white border-b border-gray-200">
        <h2 class="text-2xl font-semibold mb-6">Your Forum Posts</h2>
        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = auth()->user()->posts()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-white border rounded-lg hover:border-gray-400 transition p-4">
                    <div class="flex items-center text-sm text-gray-500 mb-2">
                        <span>Posted <?php echo e($post->created_at->diffForHumans()); ?></span>
                        <span class="mx-2">•</span>
                        <span><?php echo e($post->threads->count()); ?> <?php echo e(Str::plural('reply', $post->threads->count())); ?></span>
                    </div>
                    <h3 class="text-lg font-semibold">
                        <a href="<?php echo e(route('posts.show', $post)); ?>" class="hover:text-blue-600">
                            <?php echo e($post->title); ?>

                        </a>
                    </h3>
                    <div class="mt-3 flex items-center space-x-3">
                        <a href="<?php echo e(route('posts.edit', $post)); ?>" class="text-blue-600 hover:text-blue-800 text-sm">Edit</a>
                        <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:text-red-800 text-sm">Delete</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500">You haven't created any forum posts yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div> <?php /**PATH C:\xampp\htdocs\shophawk\resources\views/dashboard/myforum.blade.php ENDPATH**/ ?>