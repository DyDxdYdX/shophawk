<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h1 class="text-2xl font-bold mb-6">Chat</h1>
                    
                    <div class="bg-gray-50 rounded-lg">
                        <div class="flex" style="height: 70vh;">
                            <!-- Users List -->
                            <div class="w-64 border-r border-gray-200 bg-white rounded-l-lg">
                                <div class="p-4">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div 
                                            class="py-2 px-3 cursor-pointer hover:bg-gray-50 rounded-md"
                                            onclick="startChat(<?php echo e($user->id); ?>, '<?php echo e($user->name); ?>')"
                                        >
                                            <div class="font-medium"><?php echo e($user->name); ?></div>
                                            <div class="text-sm text-gray-500">Click to chat</div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <!-- Chat Area -->
                            <div class="flex-1 flex flex-col bg-white rounded-r-lg">
                                <div id="no-chat-selected" class="h-full flex items-center justify-center text-gray-500">
                                    Select a chat to start messaging
                                </div>

                                <div id="chat-container" class="h-full hidden flex flex-col">
                                    <!-- Chat Header -->
                                    <div class="p-4 border-b bg-gray-50">
                                        <span id="chat-user-name" class="font-medium"></span>
                                    </div>

                                    <!-- Messages Area -->
                                    <div id="messages" class="flex-1 overflow-y-auto p-4">
                                        <!-- Messages will appear here -->
                                    </div>

                                    <!-- Message Input -->
                                    <div class="p-4 border-t bg-gray-50">
                                        <form id="message-form" class="flex gap-2">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" id="selected-user" name="receiver_id" value="">
                                            <input 
                                                type="text" 
                                                name="message" 
                                                class="flex-1 rounded-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500" 
                                                placeholder="Type your message..."
                                                required
                                            >
                                            <button 
                                                type="submit"
                                                class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                            >
                                                Send
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let currentChatUser = null;

        function startChat(userId, userName) {
            currentChatUser = userId;
            document.getElementById('selected-user').value = userId;
            document.getElementById('chat-user-name').textContent = userName;
            document.getElementById('no-chat-selected').classList.add('hidden');
            document.getElementById('chat-container').classList.remove('hidden');
            loadMessages(userId);
        }

        function loadMessages(userId) {
            fetch(`/chat/messages/${userId}`)
                .then(response => response.json())
                .then(messages => {
                    const messagesDiv = document.getElementById('messages');
                    messagesDiv.innerHTML = '';
                    
                    messages.forEach(message => {
                        const isCurrentUser = message.sender_id === <?php echo e(auth()->id()); ?>;
                        const date = new Date(message.created_at);
                        const timeString = date.toLocaleTimeString('default', { 
                            hour: '2-digit', 
                            minute: '2-digit'
                        });
                        const dateString = date.toLocaleDateString('default', {
                            month: 'short',
                            day: 'numeric'
                        });
                        const messageHtml = `
                            <div class="mb-4 ${isCurrentUser ? 'text-right' : 'text-left'}">
                                <div class="inline-block">
                                    <div class="${isCurrentUser ? 'bg-indigo-500 text-white' : 'bg-gray-100'} px-4 py-2 rounded-lg text-left">
                                        ${message.message}
                                        <div class="text-[10px] ${isCurrentUser ? 'text-gray-200' : 'text-gray-500'} mt-1">
                                            ${dateString} at ${timeString}
                                        </div>
                                    </div>
                                    ${isCurrentUser ? `
                                        <div class="text-[10px] mt-1 text-gray-400 text-right">
                                            <button type="button" onclick="editMessage(${message.id}, '${message.message.replace(/'/g, "\\'")}')" class="hover:text-gray-600">✎</button>
                                            <span class="mx-1">•</span>
                                            <button type="button" onclick="deleteMessage(${message.id})" class="hover:text-gray-600">🗑</button>
                                        </div>
                                    ` : ''}
                                </div>
                            </div>
                        `;
                        messagesDiv.innerHTML += messageHtml;
                    });
                    
                    messagesDiv.scrollTop = messagesDiv.scrollHeight;
                });
        }

        function editMessage(messageId, currentText) {
            const newText = prompt('Edit message:', currentText);
            
            if (newText && newText !== currentText) {
                fetch(`/chat/messages/${messageId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify({ message: newText })
                })
                .then(response => response.json())
                .then(() => {
                    loadMessages(currentChatUser);
                });
            }
        }

        function deleteMessage(messageId) {
            if (confirm('Are you sure you want to delete this message?')) {
                fetch(`/chat/messages/${messageId}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    }
                })
                .then(response => response.json())
                .then(() => {
                    loadMessages(currentChatUser);
                });
            }
        }

        document.getElementById('message-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/chat/send', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({
                    receiver_id: currentChatUser,
                    message: formData.get('message')
                })
            })
            .then(response => response.json())
            .then(() => {
                this.reset();
                loadMessages(currentChatUser);
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\shophawk\resources\views/chat/index.blade.php ENDPATH**/ ?>