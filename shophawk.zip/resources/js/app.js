import './bootstrap';

import Alpine from 'alpinejs';

import './price-range';

window.Alpine = Alpine;

Alpine.start();
